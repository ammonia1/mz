function togglecontactform() {
    var x = document.getElementById("contact-container");
    if (x.style.display === "block") {
      x.style.display = "none";
      // bo dy должен быть overflow: hidden
    } else {
      x.style.display = "block";
    }
  } 